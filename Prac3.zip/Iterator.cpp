/**
 * @file [Iterator.cpp]
 * @brief [Implementation of the Abstract Iterator class]
 * @author [Okaile Gaesale]
 * @date [2025-09-28]
 */

#include "Iterator.h"
using namespace std;
